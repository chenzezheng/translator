using TranslatorApi.Models;

namespace TranslatorApi.Models
{
    public class TranslationResults
    {
        public string BaiduResult = "";
        public string YoudaoResult = "";
        public string TencentResult = "";
    }
}