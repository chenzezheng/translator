namespace TranslatorApi.Models
{
    public class Translation
    {
        public string Src { get; set; }
        public string Dst { get; set; }
    }
}